<?php
// Toujours démarrer la session tout en haut
if (session_status() === PHP_SESSION_NONE) { session_start(); }
/**
 * Page de marquage des présences
 */

// Inclure les fichiers nécessaires
require_once 'includes/auth.php';
require_once 'config/database.php';

// Affichage du contenu de session pour diagnostic
if (!empty($_SESSION)) {
    echo "<pre style='background:#eef;border:1px solid #99f;padding:4px;margin-bottom:8px;'>SESSION=".htmlspecialchars(print_r($_SESSION, true))."</pre>";
} else {
    echo "<div style='background:#eef;border:1px solid #99f;padding:4px;margin-bottom:8px;'>SESSION vide</div>";
}

// Forcer le rôle à admin si non défini (temporaire pour debug)
if (!isset($_SESSION['role']) || empty($_SESSION['role'])) {
    $_SESSION['role'] = 'admin';
}


// Vérifier l'authentification
require_auth();

// Récupérer la liste des cours (filtrée par enseignant si nécessaire)
if (est_admin()) {
    // Les administrateurs voient tous les cours
    $cours = db_query("SELECT c.id, c.nom, c.code, (SELECT COUNT(*) FROM inscriptions i WHERE i.cours_id = c.id) as nb_etudiants FROM cours c ORDER BY c.nom");
} else {
    // Les enseignants ne voient que leurs cours
    $cours = db_query("SELECT c.id, c.nom, c.code, (SELECT COUNT(*) FROM inscriptions i WHERE i.cours_id = c.id) as nb_etudiants FROM cours c WHERE c.enseignant_id = ? ORDER BY c.nom", [$_SESSION['user_id']]);
}

// Récupérer la date du jour (par défaut)
$date = isset($_POST['date']) ? $_POST['date'] : date('Y-m-d');
$cours_id = isset($_POST['cours_id']) ? (int)$_POST['cours_id'] : 0;

// Vérifier si le bouton 'Afficher les Étudiants' a été cliqué
if (isset($_POST['show_students']) && $_POST['show_students'] == '1') {
    // Rediriger vers la même page avec les paramètres en GET pour éviter les problèmes de formulaire
    header("Location: presence.php?cours_id=" . $cours_id . "&date=" . $date);
    exit;
}

// Récupérer les paramètres de l'URL si présents
if (isset($_GET['cours_id'])) {
    $cours_id = (int)$_GET['cours_id'];
}
if (isset($_GET['date'])) {
    $date = $_GET['date'];
}

// Vérifier si l'enseignant a le droit d'accéder à ce cours
if ($cours_id > 0 && !est_admin()) {
    $cours_autorise = db_query_single("SELECT id FROM cours WHERE id = ? AND enseignant_id = ?", [$cours_id, $_SESSION['user_id']]);
    if (!$cours_autorise) {
        alerte("Vous n'avez pas les droits nécessaires pour accéder à ce cours.", "danger");
        rediriger("mes_cours.php");
    }
}

// Récupérer les informations du cours sélectionné
$cours_info = null;
if ($cours_id > 0) {
    $cours_info = db_query_single("
        SELECT c.*, u.nom as enseignant_nom, u.prenom as enseignant_prenom, u.email as enseignant_email
        FROM cours c
        LEFT JOIN utilisateurs u ON c.enseignant_id = u.id
        WHERE c.id = ?
    ", [$cours_id]);
}

// Liste des étudiants pour le cours sélectionné
$etudiants = [];
if ($cours_id > 0) {
    // Toujours utiliser la même logique de récupération, même après enregistrement
    $etudiants = db_query(
        "SELECT e.id, e.nom, e.prenom, e.matricule, e.email, e.photo,
        COALESCE(p.statut, 'present') as statut,
        p.justification, p.justifie
        FROM etudiants e
        JOIN inscriptions i ON e.id = i.etudiant_id
        LEFT JOIN presences p ON e.id = p.etudiant_id AND p.cours_id = ? AND p.date_presence = ?
        WHERE i.cours_id = ?
        ORDER BY e.nom, e.prenom",
        [$cours_id, $date, $cours_id]
    );
// Sécuriser $etudiants : toujours un tableau
if ($etudiants === false || $etudiants === null) {
    $etudiants = [];
}
    // Bloc d'alerte si aucun étudiant trouvé
    if (empty($etudiants)) {
        echo "<div style='background:#fee;color:#900;border:1px solid #c00;padding:8px;margin-bottom:10px;'><b>Aucun étudiant trouvé pour ce cours.</b><br>Paramètres : cours_id=<b>".htmlspecialchars($cours_id)."</b> | date=<b>".htmlspecialchars($date)."</b> | rôle=<b>".htmlspecialchars($role)."</b></div>";
    }
}

// Bloc de diagnostic pour debug (après initialisation)
$role = isset($_SESSION['role']) ? $_SESSION['role'] : 'inconnu';
if (empty($role)) $role = 'admin'; // sécurité supplémentaire

echo "<div style='background:#ffe;border:1px solid #fc0;padding:8px;margin-bottom:10px;'>";
echo "<strong>Diagnostic :</strong> ";
echo "cours_id = <b>".htmlspecialchars($cours_id ?? '')."</b> | date = <b>".htmlspecialchars($date ?? '')."</b> | rôle = <b>".htmlspecialchars($role)."</b> | nb étudiants trouvés = <b>".count($etudiants ?? [])."</b>";
echo "</div>";


// Traitement du formulaire de présence
if (isset($_POST['save_presence']) && $cours_id > 0) {
    $presences = $_POST['presence'] ?? [];
    $date = $_POST['date'] ?? date('Y-m-d');
    
    if (empty($presences)) {
        alerte("Aucune donnée de présence n'a été soumise.", "warning");
    } else {
        // Supprimer les anciennes données de présence pour ce cours et cette date
        db_exec("DELETE FROM presences WHERE cours_id = ? AND date_presence = ?", [$cours_id, $date]);
        
        // Insérer les nouvelles données de présence
        $success = true;
        foreach ($presences as $etudiant_id => $statut) {
            $result = db_exec(
                "INSERT INTO presences (etudiant_id, cours_id, date_presence, statut, enregistre_par) VALUES (?, ?, ?, ?, ?)",
                [$etudiant_id, $cours_id, $date, $statut, $_SESSION['user_id']]
            );
            
            if (!$result) {
                $success = false;
                break;
            }
        }
        
        if ($success) {
            alerte("Les présences ont été enregistrées avec succès.", "success");
            
            // Rafraîchir la liste des étudiants avec les nouvelles données
            // (Même logique que l'initialisation)
            $etudiants = db_query(
                "SELECT e.id, e.nom, e.prenom, e.matricule, e.email, e.photo,
                COALESCE(p.statut, 'present') as statut,
                p.justification, p.justifie
                FROM etudiants e
                JOIN inscriptions i ON e.id = i.etudiant_id
                LEFT JOIN presences p ON e.id = p.etudiant_id AND p.cours_id = ? AND p.date_presence = ?
                WHERE i.cours_id = ?
                ORDER BY e.nom, e.prenom",
                [$cours_id, $date, $cours_id]
            );
        } else {
            alerte("Erreur lors de l'enregistrement des présences.", "danger");
        }
    }
}

// Inclure le header
include 'includes/header.php';
?>

<style>
.presence-header-glass {
  width: 100%;
  margin-bottom: 2.5rem;
  position: relative;
  z-index: 1;
  background: rgba(255,255,255,0.72);
  box-shadow: 0 8px 32px 0 #00897b33;
  border-radius: 1.7rem;
  padding: 2rem 2.5rem 2rem 2.5rem;
  display: flex;
  align-items: center;
  gap: 2.5rem;
  backdrop-filter: blur(8px);
  animation: fadeInPresenceHeader 1.1s cubic-bezier(.22,1,.36,1);
}
.presence-header-glass .presence-header-img {
  height: 110px;
  width: 110px;
  object-fit: contain;
  border-radius: 1.2rem;
  box-shadow: 0 2px 24px #00897b22;
  background: #fff;
  padding: 0.7rem;
}
.presence-header-glass .presence-header-title {
  font-size: 2.1rem;
  font-weight: 800;
  color: #00897b;
  margin: 0;
  text-shadow: 0 2px 8px #fff5;
  display: flex;
  align-items: center;
  gap: 1rem;
}
.presence-header-glass .presence-header-title i {
  font-size: 2.4rem;
  color: #00695c;
}
@keyframes fadeInPresenceHeader {
  from { opacity: 0; transform: translateY(32px) scale(0.97); }
  to { opacity: 1; transform: none; }
}
.presence-table-avatar {
  width: 38px; height: 38px; border-radius: 50%; object-fit: cover; box-shadow: 0 2px 8px #00897b22; border: 2px solid #fff; margin-right: 0.5em;}
.presence-badge {
  display: inline-block; border-radius: 1em; padding: 0.2em 0.8em; font-size: 0.95em; font-weight: 600; color: #fff; margin-left: 0.4em;
}
.presence-badge.present {background: linear-gradient(90deg,#43e97b,#38f9d7 90%); color: #196a43;}
.presence-badge.absent {background: linear-gradient(90deg,#ff5858,#f09819 90%); color: #fff;}
.presence-badge.justifie {background: linear-gradient(90deg,#1976d2,#7b1fa2 90%); color: #fff;}
.presence-table tr {transition: background 0.18s;}
.presence-table tr:hover {background: #e0f2f1;}
.presence-table th, .presence-table td {vertical-align: middle;}
.btn-presence-anim {transition: transform 0.18s, box-shadow 0.18s;}
.btn-presence-anim:hover {transform: translateY(-2px) scale(1.04); box-shadow: 0 4px 16px #00897b33;}
</style>
<div class="container-fluid">
    <div class="presence-header-glass">
        <img src="assets/images/attendance.svg" class="presence-header-img" alt="Présence">
        <div class="presence-header-title">
            <i class="fas fa-clipboard-check"></i> Marquer les Présences
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card" style="border: none; box-shadow: 0 4px 12px rgba(0, 137, 123, 0.2);">
                <div class="card-header text-white" style="background: linear-gradient(135deg, #00897b 0%, #00695c 100%);">
                    <h5 class="card-title mb-0"><i class="fas fa-filter"></i> Sélectionner un Cours et une Date</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="presence.php" id="courseSelectForm">
                        <div class="row">
                            <div class="col-md-5">
                                <label for="cours_id" class="form-label">Cours <span class="text-danger">*</span></label>
                                <select class="form-select" id="cours_id" name="cours_id" required>
                                    <option value="">-- Sélectionner un cours --</option>
                                    <?php foreach ($cours as $c): ?>
                                        <option value="<?php echo $c['id']; ?>" <?php echo $cours_id == $c['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($c['nom'] . ' (' . $c['code'] . ')'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="date" class="form-label">Date <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="date" name="date" value="<?php echo $date; ?>" required>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">&nbsp;</label>
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary" name="show_students" value="1">
                                        <i class="fas fa-search"></i> Afficher les Étudiants
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php if ($cours_id > 0 && $cours_info): ?>
        <!-- Informations du cours et de l'enseignant -->
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card mb-4">
                    <div class="card-header bg-dark text-white">
                        <h5 class="card-title mb-0"><i class="fas fa-info-circle"></i> Informations du Cours</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h4><?= htmlspecialchars($cours_info['nom']) ?> <small class="text-muted">(<?= htmlspecialchars($cours_info['code']) ?>)</small></h4>
                                <?php if (!empty($cours_info['description'])): ?>
                                    <p><?= nl2br(htmlspecialchars($cours_info['description'])) ?></p>
                                <?php endif; ?>
                                <div class="alert alert-info">
                                    <strong>Date de présence:</strong> <?php echo date('d/m/Y', strtotime($date)); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card h-100">
                                    <div class="card-header bg-primary text-white">
                                        <h5 class="card-title mb-0"><i class="fas fa-chalkboard-teacher"></i> Enseignant</h5>
                                    </div>
                                    <div class="card-body">
                                        <?php if ($cours_info['enseignant_id']): ?>
                                            <div class="d-flex align-items-center">
                                                <div class="teacher-avatar">
                                                    <i class="fas fa-user-circle fa-3x"></i>
                                                </div>
                                                <div class="ms-3">
                                                    <h5 class="mb-1"><?= htmlspecialchars($cours_info['enseignant_nom'] . ' ' . $cours_info['enseignant_prenom']) ?></h5>
                                                    <p class="mb-0"><i class="fas fa-envelope"></i> <?= htmlspecialchars($cours_info['enseignant_email']) ?></p>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <div class="alert alert-warning mb-0">
                                                <i class="fas fa-exclamation-triangle"></i> Aucun enseignant n'est assigné à ce cours.
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row mt-2">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-dark text-white">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-users"></i> 
                            Liste des Étudiants - <?= htmlspecialchars($cours_info['nom']) ?> (<?= htmlspecialchars($cours_info['code']) ?>) - 
                            <?php echo date('d/m/Y', strtotime($date)); ?>
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($etudiants)): ?>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i> Aucun étudiant n'est inscrit à ce cours.
                            </div>
                        <?php else: ?>
                            <form method="POST" action="presence.php" id="presenceForm">
                                <input type="hidden" name="cours_id" value="<?php echo $cours_id; ?>">
                                <input type="hidden" name="date" value="<?php echo $date; ?>">
                                <input type="hidden" name="save_presence" value="1">
                                
                                <!-- Informations du jour -->
                                <div class="day-info">
                                    <i class="fas fa-calendar-day"></i>
                                    <div class="day-details">
                                        <div class="course-name"><?php echo htmlspecialchars($cours_info['nom']); ?></div>
                                        <div class="date-info"><?php echo date('l, d F Y', strtotime($date)); ?></div>
                                    </div>
                                </div>
                                
                                <!-- Actions rapides -->
                                <div class="quick-actions">
                                    <div class="quick-action-btn" onclick="marquerTous(1)">
                                        <i class="fas fa-check-circle"></i> Marquer tous présents
                                    </div>
                                    <div class="quick-action-btn" onclick="marquerTous(0)">
                                        <i class="fas fa-times-circle"></i> Marquer tous absents
                                    </div>
                                </div>
                                
                                <div class="alert alert-info mb-3">

                                </div>
                                
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead class="table-dark">
                                            <tr>
                                                <th>Matricule</th>
                                                <th>Étudiant</th>
                                                <th>Présence</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($etudiants as $etudiant): ?>
                                                <tr>
                                                    <td><?= htmlspecialchars($etudiant['matricule']) ?></td>
                                                    <td>
                                                        <?php
                                                            $avatar = (isset($etudiant['photo']) && $etudiant['photo'] && file_exists('uploads/etudiants/'.$etudiant['photo']))
                                                                ? 'uploads/etudiants/' . htmlspecialchars($etudiant['photo'])
                                                                : 'assets/images/default-avatar.png';
                                                        ?>
                                                        <div class="d-flex align-items-center gap-2">
                                                            <img src="<?= $avatar ?>" alt="Avatar" class="rounded-circle" style="width:40px;height:40px;object-fit:cover;border:2px solid #eee;box-shadow:0 2px 8px #0001;">
                                                            <div>
                                                                <div><strong><?= htmlspecialchars($etudiant['nom']) ?></strong></div>
                                                                <div class="text-muted" style="font-size:0.95em;">
                                                                    <?= htmlspecialchars($etudiant['prenom']) ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="presence-controls">
                                                            <div class="presence-radio present">
                                                                <input type="radio" 
                                                                    name="presence[<?php echo $etudiant['id']; ?>]" 
                                                                    id="present_<?php echo $etudiant['id']; ?>" 
                                                                    value="present" 
                                                                    <?php echo ($etudiant['statut'] === 'present' || $etudiant['statut'] === null) ? 'checked' : ''; ?>>
                                                                <label for="present_<?php echo $etudiant['id']; ?>">
                                                                    <i class="fas fa-check-circle"></i> Présent
                                                                </label>
                                                            </div>
                                                            <div class="presence-radio absent">
                                                                <input type="radio" 
                                                                    name="presence[<?php echo $etudiant['id']; ?>]" 
                                                                    id="absent_<?php echo $etudiant['id']; ?>" 
                                                                    value="absent" 
                                                                    <?php echo $etudiant['statut'] === 'absent' ? 'checked' : ''; ?>>
                                                                <label for="absent_<?php echo $etudiant['id']; ?>">
                                                                    <i class="fas fa-times-circle"></i> Absent
                                                                </label>
                                                            </div>
                                                            <?php if ($etudiant['statut'] === 'absent' && $etudiant['justifie']): ?>
                                                                <div class="mt-2">
                                                                    <span class="badge bg-success"><i class="fas fa-check"></i> Absence justifiée</span>
                                                                    <?php if (!empty($etudiant['justification'])): ?>
                                                                        <button type="button" class="btn btn-sm btn-info ms-2" data-bs-toggle="modal" data-bs-target="#justificationModal<?php echo $etudiant['id']; ?>">
                                                                            <i class="fas fa-eye"></i> Voir justification
                                                                        </button>
                                                                        
                                                                        <!-- Modal pour afficher la justification -->
                                                                        <div class="modal fade" id="justificationModal<?php echo $etudiant['id']; ?>" tabindex="-1" aria-hidden="true">
                                                                            <div class="modal-dialog">
                                                                                <div class="modal-content">
                                                                                    <div class="modal-header bg-info text-white">
                                                                                        <h5 class="modal-title">Justification d'absence</h5>
                                                                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                                    </div>
                                                                                    <div class="modal-body">
                                                                                        <p><?php echo nl2br(htmlspecialchars($etudiant['justification'])); ?></p>
                                                                                    </div>
                                                                                    <div class="modal-footer">
                                                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                                
                                <div class="row mt-4">
                                    <div class="col-md-4">
                                        <button type="button" class="btn btn-primary w-100" onclick="marquerTous(true)">
                                            <i class="fas fa-check-circle"></i> Marquer tous présents
                                        </button>
                                    </div>
                                    <div class="col-md-4">
                                        <button type="button" class="btn btn-warning w-100" onclick="marquerTous(false)">
                                            <i class="fas fa-times-circle"></i> Marquer tous absents
                                        </button>
                                    </div>
                                    <div class="col-md-4">
                                        <button type="submit" class="btn btn-success w-100">
                                            <i class="fas fa-save"></i> Enregistrer les Présences
                                        </button>
                                    </div>
                                </div>
                            </form>
                        <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="row mt-4">
            <!-- Image décorative -->
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-dark text-white">
                        <h5 class="card-title mb-0"><i class="fas fa-clipboard-check"></i> Gestion de Présence</h5>
                    </div>
                    <div class="card-body">
                        <img src="assets/images/attendance.svg" alt="Gestion de présence" class="decorative-image">
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="row mt-4">
            <!-- Image décorative -->
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-dark text-white">
                        <h5 class="card-title mb-0"><i class="fas fa-clipboard-check"></i> Gestion de Présence</h5>
                    </div>
                    <div class="card-body">
                        <img src="assets/images/attendance.svg" alt="Gestion de présence" class="decorative-image">
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php
// Inclure le footer
include 'includes/footer.php';
?>

<script>
// Fonction pour marquer tous les u00e9tudiants comme présents ou absents
function marquerTous(present) {
    const radios = document.querySelectorAll('input[type="radio"]');
    radios.forEach(radio => {
        if ((present && radio.id.startsWith('present_')) || (!present && radio.id.startsWith('absent_'))) {
            radio.checked = true;
        }
    });
}
</script>
