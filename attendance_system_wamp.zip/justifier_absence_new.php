<?php
/**
 * Page permettant aux u00e9tudiants de justifier leurs absences
 * Version simplifiée et fonctionnelle
 */

// Inclure les fichiers nécessaires
require_once 'config/database.php';

// Fonctions utilitaires
function securiser($donnee) {
    $donnee = trim($donnee);
    $donnee = stripslashes($donnee);
    $donnee = htmlspecialchars($donnee);
    return $donnee;
}

// Initialiser les variables
$matricule = '';
$absences = [];
$message = '';
$message_type = 'info';
$etudiant = null;

// Traitement du formulaire de recherche d'u00e9tudiant
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['rechercher'])) {
    $matricule = securiser($_POST['matricule']);
    
    // Rechercher l'u00e9tudiant
    $etudiant = db_query_single("SELECT * FROM etudiants WHERE matricule = ?", [$matricule]);
    
    if ($etudiant) {
        // Récupérer les absences de l'u00e9tudiant
        $absences = db_query(
            "SELECT p.id, p.date_presence, c.nom as cours_nom, c.code as cours_code, p.statut, p.justifie, p.justification 
            FROM presences p 
            JOIN cours c ON p.cours_id = c.id 
            WHERE p.etudiant_id = ? AND p.statut = 'absent' 
            ORDER BY p.date_presence DESC",
            [$etudiant['id']]
        );
    } else {
        $message = "Aucun u00e9tudiant trouvé avec ce matricule.";
        $message_type = 'danger';
    }
}

// Traitement du formulaire de justification
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['justifier'])) {
    $absence_id = (int)$_POST['absence_id'];
    $justification = securiser($_POST['justification']);
    $matricule = securiser($_POST['matricule']);
    
    if (empty($justification)) {
        $message = "Veuillez fournir une justification.";
        $message_type = 'danger';
    } else {
        // Mettre u00e0 jour directement la table presences
        $result = db_exec(
            "UPDATE presences SET justification = ?, justifie = TRUE WHERE id = ?",
            [$justification, $absence_id]
        );
        
        if ($result) {
            $message = "Votre absence a u00e9té justifiée avec succès.";
            $message_type = 'success';
            
            // Rechercher u00e0 nouveau l'u00e9tudiant pour mettre u00e0 jour la liste des absences
            $etudiant = db_query_single("SELECT * FROM etudiants WHERE matricule = ?", [$matricule]);
            
            if ($etudiant) {
                // Récupérer les absences de l'u00e9tudiant
                $absences = db_query(
                    "SELECT p.id, p.date_presence, c.nom as cours_nom, c.code as cours_code, p.statut, p.justifie, p.justification 
                    FROM presences p 
                    JOIN cours c ON p.cours_id = c.id 
                    WHERE p.etudiant_id = ? AND p.statut = 'absent' 
                    ORDER BY p.date_presence DESC",
                    [$etudiant['id']]
                );
            }
        } else {
            $message = "Erreur lors de la justification de l'absence.";
            $message_type = 'danger';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Justification d'Absences</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            border: none;
        }
        .card-header {
            border-radius: 10px 10px 0 0;
            background: linear-gradient(135deg, #1976d2 0%, #0d47a1 100%);
            color: white;
            font-weight: bold;
        }
        .btn-primary {
            background: linear-gradient(135deg, #1976d2 0%, #0d47a1 100%);
            border: none;
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #0d47a1 0%, #1976d2 100%);
        }
        .table {
            border-radius: 10px;
            overflow: hidden;
        }
        .badge {
            font-size: 0.9em;
            padding: 6px 10px;
        }
        .navbar {
            background: linear-gradient(135deg, #1976d2 0%, #0d47a1 100%);
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-clipboard-check"></i> Gestion de Présence
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php"><i class="fas fa-home"></i> Accueil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="justifier_absence_new.php"><i class="fas fa-clipboard-check"></i> Justifier une absence</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php"><i class="fas fa-sign-in-alt"></i> Connexion</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card shadow-lg">
                    <div class="card-header py-3">
                        <h3 class="mb-0"><i class="fas fa-clipboard-check"></i> Justification d'Absences</h3>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($message)): ?>
                            <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                                <i class="fas fa-info-circle"></i> <?php echo $message; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" action="" class="mb-4">
                            <div class="row align-items-end">
                                <div class="col-md-8">
                                    <label for="matricule" class="form-label">Entrez votre matricule</label>
                                    <input type="text" class="form-control" id="matricule" name="matricule" value="<?php echo $matricule; ?>" required>
                                </div>
                                <div class="col-md-4">
                                    <button type="submit" name="rechercher" class="btn btn-primary w-100">
                                        <i class="fas fa-search"></i> Rechercher
                                    </button>
                                </div>
                            </div>
                        </form>
                        
                        <?php if ($etudiant): ?>
                            <div class="alert alert-success">
                                <h5><i class="fas fa-user"></i> u00c9tudiant: <?php echo htmlspecialchars($etudiant['prenom'] . ' ' . $etudiant['nom']); ?></h5>
                                <p class="mb-0">Matricule: <?php echo htmlspecialchars($etudiant['matricule']); ?></p>
                            </div>
                            
                            <?php if (empty($absences)): ?>
                                <div class="alert alert-info">
                                    <i class="fas fa-check-circle"></i> Vous n'avez aucune absence u00e0 justifier.
                                </div>
                            <?php else: ?>
                                <h4 class="mb-3">Liste de vos absences</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead style="background: linear-gradient(135deg, #1976d2 0%, #0d47a1 100%); color: white;">
                                            <tr>
                                                <th>Date</th>
                                                <th>Cours</th>
                                                <th>Statut</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($absences as $absence): ?>
                                                <tr>
                                                    <td><?php echo date('d/m/Y', strtotime($absence['date_presence'])); ?></td>
                                                    <td><?php echo htmlspecialchars($absence['cours_nom'] . ' (' . $absence['cours_code'] . ')'); ?></td>
                                                    <td>
                                                        <?php if ($absence['justifie']): ?>
                                                            <span class="badge bg-success"><i class="fas fa-check-circle"></i> Justifiée</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-danger"><i class="fas fa-times-circle"></i> Non justifiée</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if (!$absence['justifie']): ?>
                                                            <form method="POST" action="">
                                                                <input type="hidden" name="absence_id" value="<?php echo $absence['id']; ?>">
                                                                <input type="hidden" name="matricule" value="<?php echo $matricule; ?>">
                                                                <div class="mb-2">
                                                                    <textarea class="form-control form-control-sm" name="justification" rows="2" placeholder="Entrez votre justification ici" required></textarea>
                                                                </div>
                                                                <button type="submit" name="justifier" class="btn btn-sm btn-primary">
                                                                    <i class="fas fa-save"></i> Justifier
                                                                </button>
                                                            </form>
                                                        <?php else: ?>
                                                            <div>
                                                                <span class="text-success"><i class="fas fa-check-circle"></i> Déjà justifiée</span>
                                                                <?php if (!empty($absence['justification'])): ?>
                                                                    <button type="button" class="btn btn-sm btn-outline-info mt-1" data-bs-toggle="modal" data-bs-target="#justificationModal<?php echo $absence['id']; ?>">
                                                                        <i class="fas fa-eye"></i> Voir justification
                                                                    </button>
                                                                    
                                                                    <!-- Modal pour voir la justification -->
                                                                    <div class="modal fade" id="justificationModal<?php echo $absence['id']; ?>" tabindex="-1" aria-labelledby="justificationModalLabel<?php echo $absence['id']; ?>" aria-hidden="true">
                                                                        <div class="modal-dialog">
                                                                            <div class="modal-content">
                                                                                <div class="modal-header" style="background-color: #1976d2; color: white;">
                                                                                    <h5 class="modal-title" id="justificationModalLabel<?php echo $absence['id']; ?>">
                                                                                        Justification du <?php echo date('d/m/Y', strtotime($absence['date_presence'])); ?>
                                                                                    </h5>
                                                                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                                </div>
                                                                                <div class="modal-body">
                                                                                    <p><strong>Cours:</strong> <?php echo htmlspecialchars($absence['cours_nom']); ?></p>
                                                                                    <div class="card">
                                                                                        <div class="card-header bg-light">Contenu de la justification</div>
                                                                                        <div class="card-body">
                                                                                            <?php echo nl2br(htmlspecialchars($absence['justification'])); ?>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="modal-footer">
                                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                <?php endif; ?>
                                                            </div>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                                
                                <div class="alert alert-warning mt-3">

                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer text-center py-3">
                        <a href="index.php" class="btn btn-secondary"><i class="fas fa-home"></i> Retour u00e0 l'accueil</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
